# Task 15 real macOS CI RED/GREEN

The first allocated Xcode 16.4 simulator build failed during Swift module
emission. The log identified actor-isolated objects instantiated in default
arguments and `WKWebView` methods whose return values did not satisfy the
void-returning navigation protocol.

The regression contract first failed against those declarations. Production
dependencies are now created inside main-actor initializers, while the WebKit
conformance exposes distinct void-returning adapter methods. The contract and
all Linux project contracts pass; the next macOS Actions run is the compiler
GREEN check.

The second compiler run passed those declarations and then exposed one final
definite-initialization error in `NewsPresentation`: a filtering closure read a
stored property before `articles` was initialized. The pinned article is now
computed in a local constant and assigned before the remaining article list is
built.

The third compiler run reached `ImageCache` and found that Swift 6 could not
infer the optional result type for the cancellation branch of its unannotated
download task. The task now declares `Task<Data?, Never>` explicitly, preserving
the existing cancellation behavior while providing the compiler's missing
context.

After compilation turned green, the full unit suite exposed a CI-only race in
two bounded-image transport tests. The transport returned the correct
`responseTooLarge` error and stopped the protocol, but the synthetic protocol's
10 ms chunk cadence could enqueue every chunk before URLSession's delegate queue
processed cancellation. The stub cadence is now 250 ms, making the same early
cancellation assertions deterministic without changing production behavior.
